@extends('adminlte::page')

@section('title', 'AMS - HELP')

@section('content_header')
<h1>
    AMS Documentation
    <small>Current version 1.0</small>
</h1>
@stop

@section('content')
<!-- Main content -->
<div class="content body">

    <section id="introduction">
        <h2 class="page-header"><a href="#introduction">Introduction</a></h2>
        <p class="lead">
            <b>AMS</b> adalah Asset management system ...
           
        </p>
    </section><!-- /#introduction -->
    @stop
    @section('js')

    @stop