after install/clone, run:<br>
1.composer install <br>
2.php artisan key:generate <br>  
3.php artisan cache:clear <br>
4.php artisan migrate